var checkall = document.getElementsByName('allChecked')
var allinput = document.getElementsByName('shopB')
var count = document.querySelector('.total-amount')
var shop = document.querySelector('.shop').children


function inputcheck(a) {
    allinput.forEach((input) => {
        input.checked = a
        var recolor=input.parentNode.parentNode.parentNode
        if(a) recolor.style.backgroundColor='#FFF4E8'
        else recolor.style.backgroundColor='#FFFFFF'
    })
}
checkall[0].addEventListener('click', function () {
    inputcheck(this.checked)
    if(checkall[0].checked) count.innerHTML=shop.length
    else count.innerHTML=0
    checkall[1].checked = !checkall[1].checked
})
checkall[1].addEventListener('click', function () {
    if(checkall[1].checked) count.innerHTML=shop.length
    else count.innerHTML=0
    inputcheck(this.checked)
    checkall[0].checked = !checkall[0].checked
})
allinput.forEach((input) => {
    input.addEventListener('click', function(){
        var n = 0
        var recolor=input.parentNode.parentNode.parentNode
        allinput.forEach((input) => {
            if (input.checked === true) n++
        })
        if (input.checked === false) {
            checkall[0].checked = false
            checkall[1].checked = false
            recolor.style.backgroundColor='#FFFFFF'
        }
        else{
            recolor.style.backgroundColor='#FFF4E8'
        }
        count.innerHTML = n
    })
})

